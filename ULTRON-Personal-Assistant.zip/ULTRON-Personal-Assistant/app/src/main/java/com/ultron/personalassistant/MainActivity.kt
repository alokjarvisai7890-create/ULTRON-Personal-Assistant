package com.ultron.personalassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Navy = Color(0xFF050B18)
private val Neon = Color(0xFF20BFFF)
private val Panel = Color(0xFF101D31)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { UltronHome() }
    }
}

@Composable
private fun UltronHome() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var recognized by remember { mutableStateOf("Tap the microphone and speak.") }
    var status by remember { mutableStateOf("SYSTEM ONLINE • LOCAL DEMO") }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            recognized = spoken
            status = "VOICE INPUT RECEIVED"
        } else {
            status = "NO SPEECH DETECTED"
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startSpeech(context) { speechLauncher.launch(it) }
        else status = "MICROPHONE PERMISSION DENIED"
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon,
            background = Navy,
            surface = Panel,
            onPrimary = Navy,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF102B49), Navy, Color.Black))
            ).padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(24.dp))
                Text("ULTRON", color = Neon, fontSize = 34.sp, fontWeight = FontWeight.Black)
                Text("YOUR PERSONAL AI", color = Color.LightGray, letterSpacing = 4.sp, fontSize = 11.sp)
                Spacer(Modifier.height(30.dp))

                // Stylized original neon core; not an official Marvel asset.
                Box(
                    Modifier.size(190.dp)
                        .background(Brush.radialGradient(listOf(Color(0xFF155D91), Color(0xFF071629), Navy)), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("◈", color = Neon, fontSize = 104.sp, fontWeight = FontWeight.Thin)
                }
                Spacer(Modifier.height(18.dp))
                Text(status, color = Neon, fontSize = 11.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(22.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel.copy(alpha = .92f)),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text("VOICE CONSOLE", color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(recognized, color = Color.White, fontSize = 16.sp)
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = {
                                val granted = ContextCompat.checkSelfPermission(
                                    context, Manifest.permission.RECORD_AUDIO
                                ) == PackageManager.PERMISSION_GRANTED
                                if (granted) startSpeech(context) { speechLauncher.launch(it) }
                                else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Neon)
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("TAP TO SPEAK", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatusTile("AI CORE", "Not connected")
                    StatusTile("AUTOMATION", "Setup needed")
                }
                Spacer(Modifier.weight(1f))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = Neon, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Sensitive actions require your approval", color = Color.LightGray, fontSize = 11.sp)
                }
                Spacer(Modifier.height(8.dp))
                Text("Prototype v0.1.0 • Android 10+", color = Color.Gray, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun StatusTile(title: String, value: String) {
    Card(
        modifier = Modifier.weight(1f),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(value, color = Color.White, fontSize = 12.sp)
        }
    }
}

private fun startSpeech(
    context: android.content.Context,
    launch: (Intent) -> Unit
) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Boss, boliye...")
    }
    try { launch(intent) } catch (_: Exception) { }
}
